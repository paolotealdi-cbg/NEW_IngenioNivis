# Applicare e pubblicare le correzioni

Il branch è stato creato e collaudato localmente; NON risulta pubblicato su GitHub, perché manca autenticazione di scrittura nell'ambiente dell'assistente.
L'archivio contiene sorgenti completi aggiornati, test, CI e documentazione, senza .git, node_modules o credenziali reali. Non contiene una build distribuita: compilare con npm.

## Se hai già un clone locale

1. Salva o committa prima le tue modifiche locali.
2. Da terminale, nella cartella del clone:

```sh
git switch main
git pull --ff-only
git switch -c fix/forecast-window-data-quality
```

3. Copia IL CONTENUTO della cartella IngenioNivis di questo archivio dentro il clone, sovrascrivendo i file corrispondenti. Includi cartelle nascoste .github e i file .env.example/.gitignore. Non sostituire o eliminare la cartella .git del clone. Non creare una cartella IngenioNivis dentro un'altra IngenioNivis.
4. Verifica e pubblica:

```sh
npm ci --include=dev
npx playwright install chromium
npm run test:all
npm audit
git add .
git commit -m "Fix forecast windows and data quality; add tests"
git push -u origin fix/forecast-window-data-quality
```

Il push usa il tuo account GitHub già autenticato (Git Credential Manager, GitHub Desktop o gh auth login). Non inviare token o password in chat.
5. Su GitHub crea una pull request dal nuovo branch verso main. Verifica il workflow Collaudo dashboard prima del merge.

## Se non hai un clone

```sh
git clone https://github.com/paolotealdi-cbg/IngenioNivis.git
cd IngenioNivis
```

Quindi segui la procedura precedente.

## Condizioni

Base della modifica: main 11a0ecb436f4d059b75fbffd54a09db9ac5d4633.
Se main contiene cambiamenti successivi, non sovrascriverli alla cieca: confronta prima i file.
Node 20.20+ o 22 LTS. Test richiedono porta 4175 libera.
La configurazione di test usa fixture artificiali; la chiamata MeteoPiemonte reale non è stata verificata.
Per uso reale definisci la NUOVA METEOPIEMONTE_API_KEY nell'ambiente del server; revoca la chiave precedentemente pubblicata. .env non viene caricato automaticamente: usa variabili d'ambiente oppure npx tsx --env-file=.env server.ts.

Vedi IngenioNivis/docs/COLLAUDO.md per tutti gli esiti e i limiti e IngenioNivis/docs/CORREZIONI.md per le modifiche.
